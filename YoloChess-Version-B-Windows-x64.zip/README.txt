YoloChess Version B
===================

Policy:
  live jrahn/yolochess transformer Space, deterministic top_k=1 at root.

Evaluator:
  Stockfish 16 hand-crafted classical evaluation (HCE).
  NNUE is explicitly disabled: Eval::useNNUE = false.
  No .nnue file is required or packaged.
  The HCE includes Stockfish's expert-tuned classical terms such as
  material/imbalance, pawn structure, mobility, king safety, threats,
  passed pawns, space, phase interpolation and winnability/endgame scaling.

Search:
  same custom iterative deepening / aspiration / PVS family as Version A
  transposition table
  quiescence search
  SEE-aware tactical ordering
  killer + history ordering
  basic late-move reductions
  repetition and 50-move handling

Stockfish's own search is compiled as upstream infrastructure but is never
invoked by the Version B core. Corresponding GPLv3 source is included.

Supported UCI limits:
  go depth N
  go nodes N
  go movetime MS
  go wtime ... btime ... winc ... binc ... [movestogo N]
  go infinite / stop
  go searchmoves ...

Internet access is required only for the YOLOChess root policy because
jrahn/chessv6 remains private. If policy is unavailable, HCE search still runs.
